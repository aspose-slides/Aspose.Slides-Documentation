using System;
using System.Threading.Tasks;
using System.IO;
using System.Linq;
using System.Text.Json;

internal static partial class Program
{
    private static ExampleContext Context = null!;
    private static Task<int> RunChecked(string[] args) => ExampleBootstrap.RunAsync(args, async ctx =>
    {
        Context = ctx;
        Example.Context = ctx;
        ctx.BeginAction("optimization-batch/batch-conversion/block-001");
        await ConvertBatch();
        string path = File.Exists("output/result.json") ? "output/result.json" : "result.json";
        using var result = JsonDocument.Parse(File.ReadAllText(path));
        var checks = new System.Collections.Generic.Dictionary<string, bool>();
        if (ctx.IsLicensed)
        {
            using var expected = JsonDocument.Parse("{\"checks.successes_per_run\":3,\"checks.failures_per_run\":2,\"checks.unique_outputs\":true,\"checks.worker_limits_observed\":true,\"checks.later_jobs_processed\":true}");
            foreach (var field in expected.RootElement.EnumerateObject())
            {
                var actual = result.RootElement;
                foreach (string part in field.Name.Split('.'))
                    actual = actual.GetProperty(part);
                ctx.Require(actual.ToString() == field.Value.ToString(), "Licensed assertion differs: " + field.Name);
                checks["licensed-" + field.Name.Replace('.', '-')] = true;
            }
        }
        else
        {
            var values = result.RootElement.TryGetProperty("checks", out var nested) ? nested : result.RootElement;
            foreach (var field in values.EnumerateObject())
                if (field.Value.ValueKind == JsonValueKind.False)
                    throw new InvalidOperationException("Evaluation assertion failed: " + field.Name);
            checks["evaluation-semantic-effect"] = true;
            checks["evaluation-valid-output"] = true;
        }

        foreach (string pdf in Directory.GetFiles(".", "*.pdf", SearchOption.AllDirectories))
            ctx.Require(File.ReadAllBytes(pdf).AsSpan(0, 5).SequenceEqual(System.Text.Encoding.ASCII.GetBytes("%PDF-")), "Invalid PDF output.");
        foreach (string png in Directory.GetFiles(".", "*.png", SearchOption.AllDirectories))
        {
            var image = PortableImage.Decode(File.ReadAllBytes(png));
            ctx.Require(image.Width > 0 && image.Height > 0, "Empty PNG output.");
        }

        ctx.Pass("optimization-batch/batch-conversion/block-001", checks);
        await Task.CompletedTask;
    });
    private static void VerifyOutput((JobResult[] Results, int Peak) sequential, (JobResult[] Results, int Peak) parallel)
    {
        foreach (var result in new[]
        {
            sequential,
            parallel
        }

        )
        {
            Example.Require(result.Results.Count(r => r.Success) == 3 && result.Results.Count(r => !r.Success) == 2, "File outcomes differ.");
            Example.Require(result.Results.Where(r => r.Success).Select(r => r.Output).Distinct().Count() == 3, "Output filenames collide.");
            Example.Require(result.Results.Single(r => r.Source.EndsWith("later.pptx")).Success, "Later job did not run.");
        }

        Example.Require(sequential.Peak <= 1 && parallel.Peak <= 2, "Worker limit exceeded.");
        Example.Json("output/results.json", new { sequential = sequential.Results, parallel = parallel.Results, sequential_peak = sequential.Peak, parallel_peak = parallel.Peak });
        Example.Result(new { successes_per_run = 3, failures_per_run = 2, unique_outputs = true, worker_limits_observed = true, later_jobs_processed = true });
    }
}
