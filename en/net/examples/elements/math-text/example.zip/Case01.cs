using Aspose.Slides;
using Aspose.Slides.MathText;

internal static partial class Program
{
    static void Case01()
    {
        using var presentation = new Presentation();
        var slide = presentation.Slides[0];

        // Add a Math shape to the slide.
        var mathShape = slide.Shapes.AddMathShape(0, 0, 720, 150);

        // Access the math paragraph.
        var mathParagraph = ((MathPortion)mathShape.TextFrame.Paragraphs[0].Portions[0]).MathParagraph;

        // Add a simple fraction: x / y
        var fraction = new MathematicalText("x").Divide("y");
        mathParagraph.Add(new MathBlock(fraction));

        // Add equation: c² = a² + b²
        var pythagoreanEquation = new MathematicalText("c")
            .SetSuperscript("2")
            .Join("=")
            .Join(new MathematicalText("a").SetSuperscript("2"))
            .Join("+")
            .Join(new MathematicalText("b").SetSuperscript("2"));

        mathParagraph.Add(pythagoreanEquation);

        VerifyCase01(presentation);
    }
}
