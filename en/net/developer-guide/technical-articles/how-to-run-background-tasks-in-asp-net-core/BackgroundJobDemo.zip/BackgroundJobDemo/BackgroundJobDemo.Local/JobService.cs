﻿using System;
using System.IO;
using System.Threading.Tasks;
using BackgroundJobDemo.Common.Client;
using BackgroundJobDemo.Common.Processor;
using BackgroundJobDemo.Local.Model;
using Microsoft.EntityFrameworkCore;

namespace BackgroundJobDemo.Local
{
    public class JobService : IJobExtractingService, IJobStatusUpdateService, IJobRegistrationService, IJobStatusService
    {
        public JobService(string fileStorageFolderPath, Func<JobsContext> dbContextFactory)
        {
            FileStorageFolderPath = fileStorageFolderPath;
            DbContextFactory = dbContextFactory;
        }

        public async Task<ScheduledJob> GetJobAsync()
        {
            using (var db = DbContextFactory())
            {
                var job = await db.Jobs.FirstOrDefaultAsync(j => j.Status == JobStatusEnum.Waiting);
                if (job == null)
                {
                    return null;
                }

                Stream stream = null;
                string jobFolder = Path.Combine(UploadsPath, job.Id);
                string filePath = Path.Combine(jobFolder, job.FileName);
                if (File.Exists(filePath))
                {
                    stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                }

                return new ScheduledJob
                {
                    JobId = job.Id,
                    FileName = job.FileName,
                    FileStream = stream
                };
            }
        }

        public Task CompleteJobAsync(string jobKey)
        {
            return Task.CompletedTask;
        }

        public async Task<string> ScheduleJobAsync(Stream stream, string fileName)
        {
            var id = Guid.NewGuid().ToString();
            string jobFolder = Path.Combine(UploadsPath, id);
            if (!Directory.Exists(jobFolder))
            {
                Directory.CreateDirectory(jobFolder);
            }

            string filePath = Path.Combine(jobFolder, fileName);
            using (FileStream output = File.Create(filePath))
            {
                await stream.CopyToAsync(output);
            }

            using (var db = DbContextFactory())
            {
                db.Jobs.Add(new JobEntity {FileName = fileName, Id = id, Status = JobStatusEnum.Waiting});
                await db.SaveChangesAsync();
            }

            return id;
        }

        public async Task<JobStatus> GetStatusAsync(string jobId)
        {
            using (var db = DbContextFactory())
            {
                var job = await db.Jobs.FirstOrDefaultAsync(j => j.Id == jobId);
                if (job == null)
                {
                    return null;
                }

                return new JobStatus
                {
                    Info = job.Info,
                    Status = GetStringStatus(job.Status)
                };
            }
        }

        public async Task UpdateStatusAsync(string jobId, string status, string info)
        {
            using (var db = DbContextFactory())
            {
                var job = await db.Jobs.FirstOrDefaultAsync(j => j.Id == jobId);
                if (job == null)
                {
                    return;
                }

                job.Info = info;
                job.Status = GetEnumStatus(status);
                await db.SaveChangesAsync();
            }
        }

        private string FileStorageFolderPath { get; }
        private Func<JobsContext> DbContextFactory { get; }

        private string UploadsPath => Path.Combine(FileStorageFolderPath, "uploads");

        private JobStatusEnum GetEnumStatus(string status)
        {
            if (status == JobStatus.c_okStatus)
            {
                return JobStatusEnum.Ok;
            }

            if (status == JobStatus.c_failedStatus)
            {
                return JobStatusEnum.Failed;
            }

            if (status == JobStatus.c_processingStatus)
            {
                return JobStatusEnum.Processing;
            }

            return JobStatusEnum.Waiting;
        }

        private string GetStringStatus(JobStatusEnum jobStatus)
        {
            switch (jobStatus)
            {
                case JobStatusEnum.Waiting:
                    return JobStatus.c_waitingStatus;
                case JobStatusEnum.Processing:
                    return JobStatus.c_processingStatus;
                case JobStatusEnum.Ok:
                    return JobStatus.c_okStatus;
                case JobStatusEnum.Failed:
                    return JobStatus.c_failedStatus;
                default:
                    return "Unknown";
            }
        }
    }
}