﻿namespace BackgroundJobDemo.Local.Model
{
    public enum JobStatusEnum
    {
        Waiting = 0,
        Processing,
        Ok,
        Failed
    }
}