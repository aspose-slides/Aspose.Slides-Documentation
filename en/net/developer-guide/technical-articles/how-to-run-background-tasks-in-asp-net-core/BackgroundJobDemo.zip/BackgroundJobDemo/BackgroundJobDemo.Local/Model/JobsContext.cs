﻿using Microsoft.EntityFrameworkCore;

namespace BackgroundJobDemo.Local.Model
{
    public class JobsContext : DbContext
    {
        public DbSet<JobEntity> Jobs { get; set; }

        public JobsContext(DbContextOptions<JobsContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
    }
}