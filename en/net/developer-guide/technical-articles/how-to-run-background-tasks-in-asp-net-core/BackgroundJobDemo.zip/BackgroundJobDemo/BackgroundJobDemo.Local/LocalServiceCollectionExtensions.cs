﻿using System;
using BackgroundJobDemo.Common.Client;
using BackgroundJobDemo.Common.Processor;
using BackgroundJobDemo.Local.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace BackgroundJobDemo.Local
{
    public static class LocalServiceCollectionExtensions
    {
        public static void AddLocal(this IServiceCollection services, LocalConfig config)
        {
            // client's services
            services.AddTransient<IJobRegistrationService>(JobServiceImplementationFactory(config));
            services.AddTransient<IJobStatusService>(JobServiceImplementationFactory(config));
            services.AddTransient<IFileStorage>(FileStorageImplementationFactory(config));

            // processor's services
            services.AddTransient<IJobExtractingService>(JobServiceImplementationFactory(config));
            services.AddTransient<IJobStatusUpdateService>(JobServiceImplementationFactory(config));
            services.AddTransient<IFileUploader>(FileStorageImplementationFactory(config));
        }

        private static Func<IServiceProvider, JobService> JobServiceImplementationFactory(LocalConfig config)
        {
            return p =>
            {
                return new JobService(config.FileStorageFolder, () =>
                {
                    var builder = new DbContextOptionsBuilder<JobsContext>();
                    builder.UseSqlite($"Data Source={config.DbFilePath}");
                    return new JobsContext(builder.Options);
                });
            };
        }

        private static Func<IServiceProvider, FileStorage> FileStorageImplementationFactory(LocalConfig config)
        {
            return p => new FileStorage(config.FileStorageFolder);
        }
    }
}