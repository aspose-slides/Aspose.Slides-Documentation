﻿using System.IO;
using System.Threading.Tasks;
using BackgroundJobDemo.Common.Client;
using BackgroundJobDemo.Common.Processor;

namespace BackgroundJobDemo.Local
{
    public class FileStorage : IFileUploader, IFileStorage
    {
        public FileStorage(string fileStorageFolderPath)
        {
            FileStorageFolderPath = fileStorageFolderPath;
        }

        public async Task UploadProcessedAsync(Stream fileStream, string fileName, string jobId)
        {
            if (!Directory.Exists(ResultsPath))
            {
                Directory.CreateDirectory(ResultsPath);
            }

            string jobResultFolder = Path.Combine(ResultsPath, jobId);
            if (!Directory.Exists(jobResultFolder))
            {
                Directory.CreateDirectory(jobResultFolder);
            }

            using (FileStream output = File.Create(Path.Combine(jobResultFolder, fileName)))
            {
                fileStream.Seek(0, SeekOrigin.Begin);
                await fileStream.CopyToAsync(output);
            }
        }

        public Task<ProcessedFile> GetProcessedAsync(string id)
        {
            string jobResultFolder = Path.Combine(ResultsPath, id);
            if (!Directory.Exists(jobResultFolder))
            {
                return Task.FromResult<ProcessedFile>(null);
            }

            string[] files = Directory.GetFiles(jobResultFolder);
            if (files.Length == 0)
            {
                return Task.FromResult<ProcessedFile>(null);
            }

            return Task.FromResult(new ProcessedFile
            {
                FileName = Path.GetFileName(files[0]),
                ContentType = "application/octet-stream",
                Stream = new FileStream(files[0], FileMode.Open,
                    FileAccess.Read)
            });
        }

        private string FileStorageFolderPath { get; }

        private string ResultsPath => Path.Combine(FileStorageFolderPath, "results");
    }
}