﻿namespace BackgroundJobDemo.Local.Model
{
    public class JobEntity
    {
        public string Id { get; set; }

        public JobStatusEnum Status { get; set; }

        public string FileName { get; set; }

        public string Info { get; set; }
    }
}