﻿namespace BackgroundJobDemo.Local
{
    public class LocalConfig
    {
        public string DbFilePath { get; set; }
        public string FileStorageFolder { get; set; }
    }
}