﻿using System;
using Amazon.DynamoDBv2;
using Amazon.S3;
using Amazon.SQS;
using BackgroundJobDemo.Common.Client;
using BackgroundJobDemo.Common.Processor;
using Microsoft.Extensions.DependencyInjection;

namespace BackgroundJobDemo.Aws
{
    public static class AwsServiceCollectionExtensions
    {
        public static void AddAws(this IServiceCollection services, AwsConfig config)
        {
            // client's services
            services.AddTransient<IJobRegistrationService>(JobServiceImplementationFactory(config));
            services.AddTransient<IJobStatusService>(JobServiceImplementationFactory(config));
            services.AddTransient<IFileStorage>(FileStorageImplementationFactory(config));
            services.AddSingleton(new AmazonS3Client(config.Region));

            // processor's services
            services.AddSingleton(new AmazonSQSClient(config.Region));
            services.AddSingleton(new AmazonDynamoDBClient(config.Region));
            services.AddTransient<IJobExtractingService>(JobServiceImplementationFactory(config));
            services.AddTransient<IJobStatusUpdateService>(JobServiceImplementationFactory(config));
            services.AddTransient<IFileUploader>(FileStorageImplementationFactory(config));
        }

        private static Func<IServiceProvider, FileStorage> FileStorageImplementationFactory(AwsConfig config)
        {
            return p => new FileStorage(p.GetService<AmazonS3Client>(), config.BucketName);
        }

        private static Func<IServiceProvider, JobService> JobServiceImplementationFactory(AwsConfig config)
        {
            return p => new JobService(
                p.GetService<AmazonSQSClient>(),
                p.GetService<AmazonS3Client>(),
                p.GetService<AmazonDynamoDBClient>(),
                config.QueueUrl,
                config.BucketName,
                config.TableName
            );
        }
    }
}