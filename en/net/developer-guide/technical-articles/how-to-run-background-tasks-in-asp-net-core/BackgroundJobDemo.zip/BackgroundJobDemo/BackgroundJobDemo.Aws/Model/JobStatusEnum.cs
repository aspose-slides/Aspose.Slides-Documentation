﻿namespace BackgroundJobDemo.Aws.Model
{
    internal enum JobStatusEnum
    {
        Waiting = 0,
        Processing,
        Ok,
        Failed
    }
}