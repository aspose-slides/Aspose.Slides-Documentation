﻿using Amazon.DynamoDBv2.DataModel;

namespace BackgroundJobDemo.Aws.Model
{
    internal class JobEntity
    {
        [DynamoDBHashKey]
        public string Id { get; set; }

        public JobStatusEnum Status { get; set; }

        public string Info { get; set; }
    }
}