﻿using System;
using System.IO;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SQS;
using Amazon.SQS.Model;
using BackgroundJobDemo.Aws.Model;
using BackgroundJobDemo.Common.Client;
using BackgroundJobDemo.Common.Processor;

namespace BackgroundJobDemo.Aws
{
    public class JobService : IJobExtractingService, IJobStatusUpdateService, IJobRegistrationService,
        IJobStatusService
    {
        public JobService(AmazonSQSClient queueClient, AmazonS3Client storageClient, AmazonDynamoDBClient dbClient,
            string queueUrl, string bucketName, string tableName)
        {
            QueueClient = queueClient;
            BlobClient = storageClient;
            DbClient = dbClient;
            QueueUrl = queueUrl;
            BucketName = bucketName;
            TableName = tableName;
        }

        public async Task<ScheduledJob> GetJobAsync()
        {
            var msgs = await QueueClient.ReceiveMessageAsync(new ReceiveMessageRequest(QueueUrl));
            if (msgs.Messages.Count == 0)
            {
                return null;
            }

            var jobId = msgs.Messages[0].Body;

            var list = await BlobClient.ListObjectsAsync(new ListObjectsRequest
                {BucketName = BucketName, Prefix = $"uploads/{jobId}"});

            if (list.S3Objects.Count == 0)
            {
                return null;
            }

            var request = new GetObjectRequest {BucketName = BucketName, Key = list.S3Objects[0].Key};
            var response = await BlobClient.GetObjectAsync(request);
            return new ScheduledJob
            {
                FileName = Path.GetFileName(response.Key),
                FileStream = response.ResponseStream,
                JobId = jobId,
                JobKey = msgs.Messages[0].ReceiptHandle
            };
        }

        public async Task CompleteJobAsync(string jobKey)
        {
            await QueueClient.DeleteMessageAsync(QueueUrl, jobKey);
        }

        public async Task<string> ScheduleJobAsync(Stream stream, string fileName)
        {
            var jobId = Guid.NewGuid().ToString();
            var request = new PutObjectRequest
            {
                BucketName = BucketName,
                Key = $"uploads/{jobId}/{fileName}",
                InputStream = stream,
                ContentType = "text/plain"
            };

            await BlobClient.PutObjectAsync(request);

            var msg = new SendMessageRequest
            {
                QueueUrl = QueueUrl,
                MessageBody = jobId
            };

            await QueueClient.SendMessageAsync(msg);

            return jobId;
        }

        public async Task<JobStatus> GetStatusAsync(string jobId)
        {
            using (var context = new DynamoDBContext(DbClient))
            {
                var job = await context.LoadAsync<JobEntity>(
                    jobId,
                    new DynamoDBOperationConfig {OverrideTableName = TableName});

                if (job == null)
                {
                    return null;
                }

                return new JobStatus {Info = job.Info, Status = GetStringStatus(job.Status)};
            }
        }

        public async Task UpdateStatusAsync(string jobId, string status, string info)
        {
            using (var context = new DynamoDBContext(DbClient))
            {
                await context.SaveAsync(
                    new JobEntity {Id = jobId, Info = info, Status = GetEnumStatus(status)},
                    new DynamoDBOperationConfig {OverrideTableName = TableName});
            }
        }

        private string TableName { get; }
        private string QueueUrl { get; }
        private string BucketName { get; }

        private AmazonSQSClient QueueClient { get; }
        private AmazonS3Client BlobClient { get; }

        private AmazonDynamoDBClient DbClient { get; }

        private JobStatusEnum GetEnumStatus(string status)
        {
            if (status == JobStatus.c_okStatus)
            {
                return JobStatusEnum.Ok;
            }

            if (status == JobStatus.c_failedStatus)
            {
                return JobStatusEnum.Failed;
            }

            if (status == JobStatus.c_processingStatus)
            {
                return JobStatusEnum.Processing;
            }

            return JobStatusEnum.Waiting;
        }

        private string GetStringStatus(JobStatusEnum jobStatus)
        {
            switch (jobStatus)
            {
                case JobStatusEnum.Waiting:
                    return JobStatus.c_waitingStatus;
                case JobStatusEnum.Processing:
                    return JobStatus.c_processingStatus;
                case JobStatusEnum.Ok:
                    return JobStatus.c_okStatus;
                case JobStatusEnum.Failed:
                    return JobStatus.c_failedStatus;
                default:
                    return "Unknown";
            }
        }
    }
}