﻿using Amazon;

namespace BackgroundJobDemo.Aws
{
    public class AwsConfig
    {
        public RegionEndpoint Region { get; set; }
        public string BucketName { get; set; }
        public string QueueUrl { get; set; }
        public string TableName { get; set; }
    }
}