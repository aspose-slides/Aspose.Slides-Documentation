﻿using System.IO;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using BackgroundJobDemo.Common.Client;
using BackgroundJobDemo.Common.Processor;

namespace BackgroundJobDemo.Aws
{
    public class FileStorage : IFileUploader, IFileStorage
    {
        public FileStorage(AmazonS3Client storageClient, string bucketName)
        {
            StorageClient = storageClient;
            BucketName = bucketName;
        }

        public async Task UploadProcessedAsync(Stream fileStream, string fileName, string jobId)
        {
            var request = new PutObjectRequest
            {
                BucketName = BucketName,
                Key = $"processed/{jobId}/{fileName}",
                InputStream = fileStream,
                ContentType = "application/octet-stream"
            };

            await StorageClient.PutObjectAsync(request);
        }

        public async Task<ProcessedFile> GetProcessedAsync(string id)
        {
            var list = await StorageClient.ListObjectsAsync(new ListObjectsRequest
                {BucketName = BucketName, Prefix = $"processed/{id}"});

            if (list.S3Objects.Count == 0)
            {
                return null;
            }

            var request = new GetObjectRequest {BucketName = BucketName, Key = list.S3Objects[0].Key};
            // response stream will be disposed in the downstream processing
            var response = await StorageClient.GetObjectAsync(request);
            return new ProcessedFile
            {
                ContentType = "application/octet-stream",
                FileName = Path.GetFileName(response.Key),
                Stream = response.ResponseStream
            };
        }

        private AmazonS3Client StorageClient { get; }

        private string BucketName { get; }
    }
}