﻿using System.Threading.Tasks;

namespace BackgroundJobDemo.Common.Processor
{
    public interface IJobExtractingService
    {
        Task<ScheduledJob> GetJobAsync();

        Task CompleteJobAsync(string jobKey);
    }
}