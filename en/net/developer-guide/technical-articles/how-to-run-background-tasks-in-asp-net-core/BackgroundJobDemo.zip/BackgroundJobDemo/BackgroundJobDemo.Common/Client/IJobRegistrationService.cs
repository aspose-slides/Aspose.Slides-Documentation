﻿using System.IO;
using System.Threading.Tasks;

namespace BackgroundJobDemo.Common.Client
{
    public interface IJobRegistrationService
    {
        Task<string> ScheduleJobAsync(Stream stream, string fileName);
    }
}