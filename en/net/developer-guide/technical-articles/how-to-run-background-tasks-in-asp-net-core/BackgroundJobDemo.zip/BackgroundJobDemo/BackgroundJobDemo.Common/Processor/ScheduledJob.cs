﻿using System.IO;

namespace BackgroundJobDemo.Common.Processor
{
    public class ScheduledJob
    {
        public string JobId { get; set; }

        public string FileName { get; set; }

        // To avoid resource leaks the stream should be disposed
        public Stream FileStream { get; set; }

        public string JobKey { get; set; }
    }
}