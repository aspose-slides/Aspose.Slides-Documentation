﻿using System.Threading.Tasks;

namespace BackgroundJobDemo.Common.Client
{
    public interface IJobStatusService
    {
        Task<JobStatus> GetStatusAsync(string jobId);
    }
}