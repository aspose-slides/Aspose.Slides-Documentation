﻿using System;
using System.IO;
using System.Threading.Tasks;
using Aspose.Slides;
using Aspose.Slides.Export;
using BackgroundJobDemo.Common.Client;

namespace BackgroundJobDemo.Common.Processor
{
    public class JobProcessor
    {
        public JobProcessor(IJobStatusUpdateService statusService,
            IFileUploader fileUploader)
        {
            StatusService = statusService;
            FileUploader = fileUploader;
        }

        public async Task ProcessAsync(ScheduledJob job)
        {
            if (job == null)
            {
                return;
            }

            await StatusService.UpdateStatusAsync(job.JobId, JobStatus.c_processingStatus, null);

            try
            {
                await ProcessStreamAsync(job.FileStream, job.FileName, job.JobId);

                await StatusService.UpdateStatusAsync(job.JobId, JobStatus.c_okStatus, $"api/result/{job.JobId}");
            }
            catch (Exception e)
            {
                await StatusService.UpdateStatusAsync(job.JobId, JobStatus.c_failedStatus, e.Message);
            }
        }

        private IJobStatusUpdateService StatusService { get; }

        private IFileUploader FileUploader { get; }

        private async Task ProcessStreamAsync(Stream inputStream, string inputFileName, string jobId)
        {
            var presentation = new Presentation(inputStream);
            using (var output = new MemoryStream())
            {
                presentation.Save(output, SaveFormat.Pdf);

                var outputFileName = $"{Path.GetFileNameWithoutExtension(inputFileName)}.pdf";

                await FileUploader.UploadProcessedAsync(output, outputFileName, jobId);
            }
        }
    }
}