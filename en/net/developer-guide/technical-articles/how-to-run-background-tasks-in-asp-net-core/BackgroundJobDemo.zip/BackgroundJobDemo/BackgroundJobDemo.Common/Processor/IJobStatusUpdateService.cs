﻿using System.Threading.Tasks;

namespace BackgroundJobDemo.Common.Processor
{
    public interface IJobStatusUpdateService
    {
        Task UpdateStatusAsync(string jobId, string status, string info);
    }
}