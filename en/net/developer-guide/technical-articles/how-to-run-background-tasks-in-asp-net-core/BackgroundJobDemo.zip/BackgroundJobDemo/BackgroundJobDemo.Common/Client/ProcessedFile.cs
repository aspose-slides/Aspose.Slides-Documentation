﻿using System.IO;

namespace BackgroundJobDemo.Common.Client
{
    public class ProcessedFile
    {
        public Stream Stream { get; set; }

        public string FileName { get; set; }

        public string ContentType { get; set; }
    }
}