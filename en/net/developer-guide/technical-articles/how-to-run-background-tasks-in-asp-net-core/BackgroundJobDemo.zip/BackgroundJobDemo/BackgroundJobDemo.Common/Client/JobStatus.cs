﻿namespace BackgroundJobDemo.Common.Client
{
    public class JobStatus
    {
        public const string c_waitingStatus = "waiting";
        public const string c_processingStatus = "processing";
        public const string c_okStatus = "ok";
        public const string c_failedStatus = "failed";

        public string Status { get; set; }

        public string Info { get; set; }
    }
}