﻿using System.Threading.Tasks;

namespace BackgroundJobDemo.Common.Client
{
    public interface IFileStorage
    {
        Task<ProcessedFile> GetProcessedAsync(string id);
    }
}