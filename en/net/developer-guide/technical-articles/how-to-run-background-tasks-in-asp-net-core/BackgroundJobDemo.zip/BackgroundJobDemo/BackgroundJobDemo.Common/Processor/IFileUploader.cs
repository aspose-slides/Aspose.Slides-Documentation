﻿using System.IO;
using System.Threading.Tasks;

namespace BackgroundJobDemo.Common.Processor
{
    public interface IFileUploader
    {
        Task UploadProcessedAsync(Stream fileStream, string fileName, string jobId);
    }
}