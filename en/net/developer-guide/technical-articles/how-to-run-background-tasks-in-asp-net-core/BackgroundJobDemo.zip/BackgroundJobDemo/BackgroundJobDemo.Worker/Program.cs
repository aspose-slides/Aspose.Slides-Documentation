﻿using System;
using System.Threading.Tasks;
using BackgroundJobDemo.Common.Processor;
using BackgroundJobDemo.Local;
using BackgroundJobDemo.Local.Model;
using Microsoft.EntityFrameworkCore;

namespace BackgroundJobDemo.Worker
{
    internal class Program
    {
        private static async Task Main(string[] args)
        {
            Console.WriteLine("Worker was started");
            Console.WriteLine("Press Ctrl+C for exit");

            bool exit = false;

            Console.CancelKeyPress += (s, eas) =>
            {
                Console.WriteLine("Exiting...");
                eas.Cancel = true;
                exit = true;
            };

            const string fileStoragePath = "add path here";
            const string dbPath = @"add path here\jobs.db";

            while (!exit)
            {
                var jobService = new JobService(fileStoragePath, () =>
                {
                    var builder = new DbContextOptionsBuilder<JobsContext>();
                    builder.UseSqlite($"Data Source={dbPath}");
                    return new JobsContext(builder.Options);
                });
                var fileStorage = new FileStorage(fileStoragePath);
                var processor = new JobProcessor(jobService, fileStorage);

                var job = await jobService.GetJobAsync();
                if (job == null)
                {
                    Console.WriteLine("Queue is empty");
                }
                else
                {
                    using (job.FileStream)
                    {
                        Console.WriteLine($"Processing job {job.JobId}...");
                        await processor.ProcessAsync(job);

                        Console.WriteLine("Job was processed");
                    }
                }

                await Task.Delay(2000);
            }
        }
    }
}