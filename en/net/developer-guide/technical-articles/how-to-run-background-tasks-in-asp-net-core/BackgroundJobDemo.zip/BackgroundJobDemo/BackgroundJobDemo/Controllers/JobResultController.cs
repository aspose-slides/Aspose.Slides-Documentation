﻿using System.Threading.Tasks;
using BackgroundJobDemo.Common.Client;
using Microsoft.AspNetCore.Mvc;

namespace BackgroundJobDemo.Controllers
{
    [ApiController]
    public class JobResultController : ControllerBase
    {
        public JobResultController(IFileStorage storage)
        {
            m_storage = storage;
        }

        [Route("api/result/{id}")]
        [HttpGet]
        public async Task<IActionResult> GetStatus(string id)
        {
            ProcessedFile result = await m_storage.GetProcessedAsync(id);
            if (result == null)
            {
                return NotFound();
            }

            return File(result.Stream, result.ContentType, result.FileName);
        }

        private readonly IFileStorage m_storage;
    }
}