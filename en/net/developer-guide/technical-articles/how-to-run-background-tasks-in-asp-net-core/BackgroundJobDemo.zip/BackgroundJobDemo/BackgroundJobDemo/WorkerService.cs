using System;
using System.Threading;
using System.Threading.Tasks;
using BackgroundJobDemo.Common.Processor;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace BackgroundJobDemo
{
    internal class WorkerService : BackgroundService
    {
        private readonly ILogger<WorkerService> m_logger;
        private readonly IJobExtractingService m_jobService;
        private readonly IJobStatusUpdateService m_statusService;
        private readonly IFileUploader m_fileUploader;

        private volatile bool m_running;

        public WorkerService(ILogger<WorkerService> logger, IJobExtractingService jobService, IJobStatusUpdateService statusService, IFileUploader fileUploader)
        {
            m_logger = logger;
            m_jobService = jobService;
            m_statusService = statusService;
            m_fileUploader = fileUploader;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            m_logger.LogInformation("Worker service was started");

            m_running = true;
            while (m_running)
            {
                try
                {
                    var processor = new JobProcessor(m_statusService, m_fileUploader);

                    var job = await m_jobService.GetJobAsync();
                    if (job == null)
                    {
                        m_logger.LogInformation("Queue is empty");
                    }
                    else
                    {
                        using (job.FileStream)
                        {
                            m_logger.LogInformation($"Processing job {job.JobId}...");
                            await processor.ProcessAsync(job);

                            await m_jobService.CompleteJobAsync(job.JobKey);

                            m_logger.LogInformation("Job was processed");
                        }
                    }
                }
                catch (Exception e)
                {
                    m_logger.LogError(e, "Job processing error");
                }

                await Task.Delay(2000, stoppingToken);
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            m_running = false;

            return Task.CompletedTask;
        }
    }
}