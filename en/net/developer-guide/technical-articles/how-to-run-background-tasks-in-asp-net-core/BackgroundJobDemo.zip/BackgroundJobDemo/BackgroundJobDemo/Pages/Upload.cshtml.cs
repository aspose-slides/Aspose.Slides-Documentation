﻿using System.IO;
using System.Threading.Tasks;
using BackgroundJobDemo.Common.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BackgroundJobDemo
{
    public class UploadModel : PageModel
    {
        private readonly IJobRegistrationService m_jobRegistrationService;

        public UploadModel(IJobRegistrationService mJobRegistrationService)
        {
            m_jobRegistrationService = mJobRegistrationService;
        }

        [BindProperty]
        public IFormFile Upload { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            using (Stream stream = Upload.OpenReadStream())
            {
                string jobId = await  m_jobRegistrationService.ScheduleJobAsync(stream, Upload.FileName);

                return RedirectToPage("Progress", new { jobId });
            }
        }
    }
}