using BackgroundJobDemo.Aws;
using BackgroundJobDemo.Local;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace BackgroundJobDemo
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            // uncomment the lines below to change the request body size limit to 256MB
            //services.Configure<IISServerOptions>(options =>
            //    options.MaxRequestBodySize = 268435456);

            //services.Configure<KestrelServerOptions>(options =>
            //    options.Limits.MaxRequestBodySize = 268435456);

            services.AddRazorPages(o =>
            {
                o.Conventions.ConfigureFilter(new IgnoreAntiforgeryTokenAttribute())
                    .AddPageRoute("/Upload", "");
            });

            services.AddControllers();

            //services.AddAws(new AwsConfig
            //{
            //    BucketName = "bucket",
            //    QueueUrl = "url",
            //    TableName = "JobsTable",
            //    Region = Amazon.RegionEndpoint.EUNorth1
            //});
            services.AddLocal(new LocalConfig{ DbFilePath = @"add path here\jobs.db", FileStorageFolder = @"add path here" });

            // comment the lines below to turn off in-process job processing
            services.AddHostedService<WorkerService>();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapRazorPages();
            });
        }
    }
}
