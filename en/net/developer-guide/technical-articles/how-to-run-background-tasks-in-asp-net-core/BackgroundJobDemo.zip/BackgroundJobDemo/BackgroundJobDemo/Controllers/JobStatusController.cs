﻿using System.Threading.Tasks;
using BackgroundJobDemo.Common.Client;
using Microsoft.AspNetCore.Mvc;

namespace BackgroundJobDemo.Controllers
{
    [ApiController]
    public class JobStatusController : ControllerBase
    {
        public JobStatusController(IJobStatusService statusService)
        {
            m_statusService = statusService;
        }

        [Route("api/status/{jobId}")]
        [HttpGet]
        public async Task<IActionResult> GetStatus(string jobId)
        {
            var res = await m_statusService.GetStatusAsync(jobId);

            if (res == null)
            {
                return NotFound();
            }

            return Ok(res);
        }

        private readonly IJobStatusService m_statusService;
    }
}