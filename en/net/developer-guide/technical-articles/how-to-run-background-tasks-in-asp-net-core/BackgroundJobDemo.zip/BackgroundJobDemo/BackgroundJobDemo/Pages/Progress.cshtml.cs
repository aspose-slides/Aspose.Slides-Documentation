﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BackgroundJobDemo
{
    public class ProgressModel : PageModel
    {
        [BindProperty]
        public string JobId { get; set; }

        public void OnGet(string jobId)
        {
            JobId = jobId;
        }
    }
}