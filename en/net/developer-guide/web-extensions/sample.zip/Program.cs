﻿using Aspose.Slides;
using Aspose.Slides.Export;
using Aspose.Slides.Export.Web;
using Aspose.Slides.SlideShow;
using Aspose.Slides.WebExtensions;

namespace PdfToPresentationToHtml
{
    class Program
    {
        static void Main(string[] args)
        {
            ImportFromPdfAndAnimateSlideTransitions();
        }

        static void ImportFromPdfAndAnimateSlideTransitions()
        {
            using (Presentation pres = new Presentation())
            {
                pres.Slides.RemoveAt(0);
                pres.Slides.AddFromPdf("sample.pdf");

                pres.Slides[0].SlideShowTransition.Type = TransitionType.Fade;
                pres.Slides[1].SlideShowTransition.Type = TransitionType.RandomBar;
                pres.Slides[2].SlideShowTransition.Type = TransitionType.Cover;
                pres.Slides[3].SlideShowTransition.Type = TransitionType.Dissolve;
                pres.Slides[4].SlideShowTransition.Type = TransitionType.Switch;
                pres.Slides[5].SlideShowTransition.Type = TransitionType.Pan;
                pres.Slides[6].SlideShowTransition.Type = TransitionType.Ferris;
                pres.Slides[7].SlideShowTransition.Type = TransitionType.Pull;
                pres.Slides[8].SlideShowTransition.Type = TransitionType.Plus;

                WebDocumentOptions options = new WebDocumentOptions
                {
                    TemplateEngine = new RazorTemplateEngine(),
                    OutputSaver = new FileOutputSaver(),
                    AnimateTransitions = true
                };

                WebDocument document = pres.ToSinglePageWebDocument(options, "templates\\single-page", "animated-pdf");
                document.Save();
            }
        }

        static void ExportSingePage()
        {
            using (Presentation pres = new Presentation("demo.pptx"))
            {
                WebDocument document = pres.ToSinglePageWebDocument("templates\\single-page", @"single-page-output");
                document.Save();
            }
        }

        static void ExportMultiPage()
        {
            using (Presentation pres = new Presentation("demo.pptx"))
            {
                WebDocument document = pres.ToMultiPageWebDocument("templates\\multi-page", @"mutil-page-output");
                document.Save();
            }
        }
    }
}
